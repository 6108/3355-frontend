import AD from "@/components/common/AD";
import Header from "@/components/layout/Header";
import Nav from "@/components/layout/Nav";
import RoomItem from "@/components/room/RoomItem";
import { useCheckLogin } from "@/hooks/useCheckLogin";
import { useGetRoomsByToken } from "@/hooks/useRoom";
import { useGetUserInfo } from "@/hooks/useUser";
import useAuthStore from "@/stores/useAuthStore";
import useRoomStore from "@/stores/useRoomStore";
import type { ChatRoomAPI, RoomAPI } from "@/types/api";
import { useEffect } from "react";
// import type { ChatRoom } from "@/types";
import { useParams } from "react-router-dom";


export default function MyChatPage() {
  const { accessToken } = useAuthStore();
  const { data, isLoading, isError, refetch } = useGetRoomsByToken(accessToken);

  const { roomActivities, updateRoomActivity, getRoomActivity } = useRoomStore();
  const checkLogin = useCheckLogin();

  useEffect(() => {
    if (!accessToken) return;
    checkLogin();
    refetch();
  }, [accessToken]);

  useEffect(() => {
    console.log(data);
  }, [data])

  return (
    <>
      <Header showLogo={true} showUser={true} showSearch={true} />
      <AD />
      <div className='flex-1 w-full h-full relative overflow-hidden'>
        <div className="h-full p-4">
          <div className="flex gap-1 items-center pb-4">
            <span className="title3-sb text-text-primary">현재 참여중인 채팅방</span>
            <span className="label5-r text-text-tertiary">{data?.content.length ?? 0}</span>
          </div>
          {(data && data.content.length > 0) ? (
            <div className="h-full flex flex-col gap-2 overflow-y-auto scrollbar-hide pb-16">
              {data?.content.map(room => {
                console.log(room);
                const activity = getRoomActivity(room.chatRoomId);
                let hasNew = false;
                if (activity?.lastViewedAt) {
                  const localDate = new Date(activity.lastViewedAt);
                  const backDate = new Date(room.lastMessageAt);

                  hasNew = backDate > localDate;
                }

                return (
                  <RoomItem key={room.chatRoomId} room={room} showDetail={true} hasNew={hasNew} isJoined={false} />
                )
              })}
            </div>
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center gap-4">
              <img src="/empty/chat.svg" alt="" />
              <p className="body1-r">현재 참여중인 방이 없습니다.</p>
            </div>
          )}
        </div>
      </div>
      <Nav />
    </>
  )
}

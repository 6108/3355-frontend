import Button from "@/components/common/Button";
import Header from "@/components/layout/Header";
import { useNavigate } from "react-router-dom";

export default function NotFoundPage() {
  const navigate = useNavigate();

  return (
    <>
      <Header showLogo={true} showUser={true} showSearch={true} />
      <div className='flex-1 w-full h-full relative overflow-hidden'>
        <div className="w-full h-full flex flex-col items-center justify-center gap-4">
          <img src="/empty/404.svg" alt="" />
          <p>페이지를 찾을 수 없습니다.</p>
          <Button className="w-22 h-12"
            onClick={() => navigate('/')}>메인으로</Button>
        </div>
      </div>
    </>
  )
}
